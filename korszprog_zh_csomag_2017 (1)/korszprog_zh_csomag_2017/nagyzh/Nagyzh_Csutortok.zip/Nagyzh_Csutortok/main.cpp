#include <iostream>
#include <functional>
#include <thread>
#include <mutex>
#include <chrono>
#include "figure.h"
#include "hero.h"
//#include "gameboard.h"
//#include "figuregenerator.h"

using namespace std;

int main()
{

	// Figure and Hero example
	cout << endl << endl << "Figure and Hero example" << endl;
	{
		Figure f1(2,12,5,3);
		Hero h1(6,34,5,4,"BRUTE");
		f1.print(); // Figure level: 2, health: 12, speed: 5, damage: 3
		h1.print(); // Hero level: 6, health: 34, speed: 5, damage: 4, ability: BRUTE
	}

//	// GameBoard test: readFile, printAll
//	cout << endl << endl << "GameBoard test: readFile, printAll" << endl;
//	GameBoard board;
//	board.readFile();
//	board.printAll();
//	/*
//	Heroes:
//	Hero level: 7, health: 12, speed: 4, damage: 3, ability: brawler
//	Hero level: 6, health: 15, speed: 4, damage: 5, ability: sharpshooter
//	Hero level: 5, health: 10, speed: 4, damage: 4, ability: hunter
//	Hero level: 8, health: 20, speed: 4, damage: 5, ability: leader
//	Figures:
//	Level 1:
//	Figure level: 1, health: 6, speed: 4, damage: 1
//	Figure level: 1, health: 5, speed: 5, damage: 1
//	Figure level: 1, health: 6, speed: 3, damage: 2
//	Figure level: 1, health: 6, speed: 4, damage: 1
//	Figure level: 1, health: 6, speed: 4, damage: 1
//	Level 2:
//	Figure level: 2, health: 7, speed: 4, damage: 2
//	Figure level: 2, health: 9, speed: 3, damage: 3
//	Figure level: 2, health: 7, speed: 3, damage: 3
//	Figure level: 2, health: 7, speed: 4, damage: 2
//	Figure level: 2, health: 7, speed: 4, damage: 2
//	Figure level: 2, health: 7, speed: 4, damage: 2
//	Level 3:
//	Figure level: 3, health: 8, speed: 4, damage: 3
//	Figure level: 3, health: 9, speed: 3, damage: 2
//	Figure level: 3, health: 8, speed: 4, damage: 3
//	Figure level: 3, health: 8, speed: 4, damage: 3
//	Figure level: 3, health: 8, speed: 4, damage: 3
//	*/


//	// GameBoard test: getResource, setResource, getFigureCount
//	cout << endl << endl << "GameBoard test: getResource, setResource, getFigureCount" << endl;
//	cout << board.getResource() << endl; // 100
//	board.setResource(250);
//	cout << board.getResource() << endl; // 250
//	cout << board.getFigureCount(0) << endl; // 4
//	cout << board.getFigureCount(1) << endl; // 5
//	cout << board.getFigureCount(2) << endl; // 6
//	cout << board.getFigureCount(3) << endl; // 5

//	// GameBoard test: newFigure, exception
//	cout << endl << endl << "GameBoard test: newFigure, exception" << endl;
//	board.newFigure(new Figure(2,12,5,3),80); // this is added
//	board.newFigure(new Figure(1,8,5,1),20); // this is added
//	board.newFigure(new Figure(3,15,5,4),120); // this is added
//	cout << board.getResource() << endl; // 30
//	board.printAll();
//	/*
//	Heroes:
//	Hero level: 7, health: 12, speed: 4, damage: 3, ability: brawler
//	Hero level: 6, health: 15, speed: 4, damage: 5, ability: sharpshooter
//	Hero level: 5, health: 10, speed: 4, damage: 4, ability: hunter
//	Hero level: 8, health: 20, speed: 4, damage: 5, ability: leader
//	Figures:
//	Level 1:
//	Figure level: 1, health: 6, speed: 4, damage: 1
//	Figure level: 1, health: 5, speed: 5, damage: 1
//	Figure level: 1, health: 6, speed: 3, damage: 2
//	Figure level: 1, health: 6, speed: 4, damage: 1
//	Figure level: 1, health: 6, speed: 4, damage: 1
//	Figure level: 1, health: 8, speed: 5, damage: 1
//	Level 2:
//	Figure level: 2, health: 7, speed: 4, damage: 2
//	Figure level: 2, health: 9, speed: 3, damage: 3
//	Figure level: 2, health: 7, speed: 3, damage: 3
//	Figure level: 2, health: 7, speed: 4, damage: 2
//	Figure level: 2, health: 7, speed: 4, damage: 2
//	Figure level: 2, health: 7, speed: 4, damage: 2
//	Figure level: 2, health: 12, speed: 5, damage: 3
//	Level 3:
//	Figure level: 3, health: 8, speed: 4, damage: 3
//	Figure level: 3, health: 9, speed: 3, damage: 2
//	Figure level: 3, health: 8, speed: 4, damage: 3
//	Figure level: 3, health: 8, speed: 4, damage: 3
//	Figure level: 3, health: 8, speed: 4, damage: 3
//	Figure level: 3, health: 15, speed: 5, damage: 4
//	*/
//	// Ez a sor kivételt dob, itt mutasd be ennek a kivételnek az elkapását, és a hibaüzenet megjelenítését.
//	board.newFigure(new Figure(2,12,5,3),80); // exception
//	// There is not enough resource for the figure.

//	// FigureGenerator test: singleton
//	cout << endl << endl << "FigureGenerator test: singleton" << endl;
//	FigureGenerator &fg=FigureGenerator::getInstance();

//	// FigureGenerator test: generateFigure
//	cout << endl << endl << "FigureGenerator test: generateFigure" << endl;
//	board.setResource(110);
//	Figure *newfig=nullptr;
//	cout << board.getFigureCount(1) << endl; // 6
//	cout << board.getFigureCount(2) << endl; // 7
//	cout << board.getFigureCount(3) << endl; // 6
//	cout << board.getResource() << endl; // 110
//	newfig=fg.generateFigure(board); // generate a level 3
//	if (newfig) newfig->print(); // Figure level: 3, health: 8, speed: 4, damage: 3
//	cout << board.getFigureCount(1) << endl; // 6
//	cout << board.getFigureCount(2) << endl; // 7
//	cout << board.getFigureCount(3) << endl; // 7
//	cout << board.getResource() << endl; // 80
//	// And now, repeat it, until possible. Generated levels will be 1, 3, 2, 1. The next would be 3, but the resource will not be enough.
//	do
//	{
//		newfig=fg.generateFigure(board); // generate a figure
//		if (newfig) newfig->print();
//	} while (newfig);
//	/*
//	Figure level: 1, health: 6, speed: 4, damage: 1
//	Figure level: 3, health: 8, speed: 4, damage: 3
//	Figure level: 2, health: 7, speed: 4, damage: 2
//	Figure level: 1, health: 6, speed: 4, damage: 1
//	There is not enough resource for the figure.
//	*/
//	cout << board.getFigureCount(1) << endl; // 8
//	cout << board.getFigureCount(2) << endl; // 8
//	cout << board.getFigureCount(3) << endl; // 8
//	cout << board.getResource() << endl; // 10

//	// Multithreading test
//	cout << endl << endl << "Multithreading test" << endl;
//	board.setResource(100000);
//	// Ezt a ciklust kell külön szálon futtatni, és egy másik szál segítségével figyelni a futását.
//	for (int i=0; i<100; i++)
//	{
//		fg.generateFigure(board);
//	}
//	// A többszálú működés miatt itt a konkrét értékek változhatnak
//	/*
//	Another second passed
//	All enemy figures: 41
//	Another second passed
//	All enemy figures: 56
//	Another second passed
//	All enemy figures: 72
//	Another second passed
//	All enemy figures: 88
//	Another second passed
//	All enemy figures: 104
//	Another second passed
//	All enemy figures: 120
//	Another second passed
//	All enemy figures: 124
//	*/

	cout << endl << endl;
	return 0;
}
