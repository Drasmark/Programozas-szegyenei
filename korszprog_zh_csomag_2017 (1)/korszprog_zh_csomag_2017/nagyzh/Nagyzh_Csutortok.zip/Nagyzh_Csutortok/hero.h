#ifndef HERO_H
#define HERO_H

#include "figure.h"
#include <string>

class Hero : public Figure
{
protected:
	string ability;
public:
	Hero(int level, int health, int speed, int damage, const string &ability);
	virtual void print() const;
};

#endif // HERO_H
