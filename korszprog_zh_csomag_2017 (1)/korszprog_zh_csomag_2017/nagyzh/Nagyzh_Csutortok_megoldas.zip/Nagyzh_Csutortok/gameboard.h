#ifndef GAMEBOARD_H
#define GAMEBOARD_H

#include "hero.h"
#include <list>
#include <map>
#include <fstream>
#include <exception>

class GameBoard
{
	list<Hero*> heroes;
	map<int,list<Figure*>> figures;
	int resource=100;
public:
	class NotEnoughResourceException: public exception
	{
		virtual const char *what() const throw()
		{
			return "There is not enough resource for the figure.";
		}
	};

	void readFile();
	void printAll() const;
	int getResource() const;
	void setResource(int value);
	int getFigureCount(int level) const;
	void newFigure(Figure *fig, int price);

	~GameBoard();
};

#endif // GAMEBOARD_H
