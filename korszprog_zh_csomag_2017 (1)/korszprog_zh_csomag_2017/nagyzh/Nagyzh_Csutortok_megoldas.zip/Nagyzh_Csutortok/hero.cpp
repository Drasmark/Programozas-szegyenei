#include "hero.h"

Hero::Hero(int level, int health, int speed, int damage, const string &ability):
	Figure(level, health, speed, damage),
	ability(ability)
{
}

void Hero::print() const
{
	cout << "Hero level: " << level << ", health: " << health << ", speed: " << speed << ", damage: " << damage << ", ability: " << ability << endl;
}
