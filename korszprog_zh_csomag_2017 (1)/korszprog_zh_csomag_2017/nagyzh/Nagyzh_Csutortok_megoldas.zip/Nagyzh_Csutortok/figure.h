#ifndef FIGURE_H
#define FIGURE_H

#include <iostream>

using namespace std;

class Figure
{
protected:
	int level, health, speed, damage;
public:
	Figure(int level, int health, int speed, int damage);
	int getLevel() const;
	void setLevel(int value);
	int getHealth() const;
	void setHealth(int value);
	int getSpeed() const;
	void setSpeed(int value);
	int getDamage() const;
	void setDamage(int value);

	virtual void print() const;
	virtual ~Figure();
};

#endif // FIGURE_H
