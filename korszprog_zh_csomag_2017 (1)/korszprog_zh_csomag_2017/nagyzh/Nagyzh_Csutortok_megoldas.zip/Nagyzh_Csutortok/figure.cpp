#include "figure.h"

Figure::Figure(int level, int health, int speed, int damage):
	level(level),
	health(health),
	speed(speed),
	damage(damage)
{
}

int Figure::getLevel() const
{
	return level;
}

void Figure::setLevel(int value)
{
	level = value;
}

int Figure::getHealth() const
{
	return health;
}

void Figure::setHealth(int value)
{
	health = value;
}

int Figure::getSpeed() const
{
	return speed;
}

void Figure::setSpeed(int value)
{
	speed = value;
}

int Figure::getDamage() const
{
	return damage;
}

void Figure::setDamage(int value)
{
	damage = value;
}

void Figure::print() const
{
	cout << "Figure level: " << level << ", health: " << health << ", speed: " << speed << ", damage: " << damage << endl;
}

Figure::~Figure()
{
}
