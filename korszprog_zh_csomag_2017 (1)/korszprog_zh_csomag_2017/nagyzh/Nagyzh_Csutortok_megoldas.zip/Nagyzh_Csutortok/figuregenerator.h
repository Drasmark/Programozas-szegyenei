#ifndef FIGUREGENERATOR_H
#define FIGUREGENERATOR_H

#include "gameboard.h"

class FigureGenerator
{
	FigureGenerator();
	FigureGenerator(const FigureGenerator&);
public:
	static FigureGenerator& getInstance();

	Figure *generateFigure(GameBoard &board) const;
};

#endif // FIGUREGENERATOR_H
