#include "figuregenerator.h"

FigureGenerator::FigureGenerator()
{
}

FigureGenerator::FigureGenerator(const FigureGenerator&)
{
}

FigureGenerator &FigureGenerator::getInstance()
{
	static FigureGenerator instance;
	return instance;
}

Figure *FigureGenerator::generateFigure(GameBoard &board) const
{
	int min_level=1;
	if (board.getFigureCount(2)<=board.getFigureCount(min_level)) min_level=2;
	if (board.getFigureCount(3)<=board.getFigureCount(min_level)) min_level=3;

	try
	{
		Figure *fig=new Figure(min_level, min_level+5, 4, min_level);
		board.newFigure(fig, min_level*10);
		return fig;
	}
	catch (exception &e)
	{
		cout << e.what() << endl;
	}
	return nullptr;
}
