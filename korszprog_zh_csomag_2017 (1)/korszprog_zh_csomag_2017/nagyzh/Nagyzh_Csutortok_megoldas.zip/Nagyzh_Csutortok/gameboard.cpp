#include "gameboard.h"

void GameBoard::readFile()
{
	ifstream input("figures.txt");
	if (input.is_open())
	{
		string type;
		input >> type;
		while (type!="*")
		{
			int level, health, speed, damage;
			input >> level >> health >> speed >> damage;
			if (type=="FIGURE")
			{
				figures[level].push_back(new Figure(level, health, speed, damage));
			}
			else if (type=="HERO")
			{
				string ability;
				input >> ability;
				heroes.push_back(new Hero(level, health, speed, damage, ability));
			}
			input >> type;
		}
		input.close();
	}
	else
	{
		cout << "Cannot open input file" << endl;
	}
}

void GameBoard::printAll() const
{
	cout << "Heroes:" << endl;
	for (Hero *h : heroes)
	{
		h->print();
	}
	cout << "Figures:" << endl;
	for (int i : {1,2,3})
	{
		cout << "Level " << i << ":" << endl;
		auto fit=figures.find(i);
		if (fit!=figures.end())
		{
			for (Figure *f : fit->second)
				f->print();
		}
	}
}

int GameBoard::getResource() const
{
	return resource;
}

void GameBoard::setResource(int value)
{
	resource = value;
}

int GameBoard::getFigureCount(int level) const
{
	if (level==0) return heroes.size();
	else
	{
		auto fit=figures.find(level);
		if (fit!=figures.end()) return fit->second.size();
		else return 0;
	}
}

void GameBoard::newFigure(Figure *fig, int price)
{
	if (price<=resource)
	{
		figures[fig->getLevel()].push_back(fig);
		resource-=price;
	}
	else
	{
		delete fig;
		throw NotEnoughResourceException();
	}
}

GameBoard::~GameBoard()
{
	for (Hero *h: heroes)
		delete h;
	for (int i : {1,2,3})
		for (Figure *f : figures[i])
			delete f;
}
